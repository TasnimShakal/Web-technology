# EzRecruit

A smart recruitment management system for a company/club/job specially for university clubs and companies. Built with PHP and JS. The project follow MVC pattern and uses MySQL as the database.

## Screenshots

- **Homepage**
  ![Screenshot 2022-12-11 021304](https://user-images.githubusercontent.com/28858998/206873647-c4545028-0a31-4eed-8fed-acafc0b8f3f9.png)

- **Admin Dashboard**
  ![Screenshot 2022-12-11 021445](https://user-images.githubusercontent.com/28858998/206873686-1f571c7a-387a-4864-b396-8e444a32ce13.png)

## Development

The needed tools for developing this project are:

- phpmyadmin
- php
- apache2
- mysql

If you are on Linux then you can go ahead and install all these **LAMP** stack and run the project to develop and if you are on linux then I will suggest you to use the **XAMPP** server software suite to easily be able to develop the project further more.

After setting up the environment you have to open the `db_connect.php` file under the **model** directory and edit the **_credentials_** for your database connection there.

> **NB**: You have to keep the project inside the directory which is the www root defined in the apache2 configuration

## Credit

- [Mushfiqur Rahman Abir](https://github.com/Abir-Tx/)

**NB: This is a project for my Webtech course**
