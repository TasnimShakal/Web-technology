<!-- A simple footer designed by Mushfiqur Rahman Abir -->
<footer>
	<hr>
	<code>
		Copyright © 2022 | <a href="https://abir-tx.github.io">Mushfiqur Rahman Abir</a>
	</code>
	<hr>
</footer>